
import { GoogleGenAI, Type } from "@google/genai";

// Standard initialization for GoogleGenAI
export async function analyzeWorkflow(description: string) {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze the following business workflow and provide a structured automation plan. Focus on cost-efficiency using custom AI agents, specialized scripts, and intelligent cloud integrations. Do not mention specific third-party tools like Zapier or Make. Workflow: "${description}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            steps: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            tools: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            estimatedSavings: { type: Type.STRING }
          },
          required: ["title", "steps", "tools", "estimatedSavings"]
        }
      }
    });

    const jsonStr = response.text;
    if (!jsonStr) {
      throw new Error("No response text returned from Gemini API");
    }

    return JSON.parse(jsonStr.trim());
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
