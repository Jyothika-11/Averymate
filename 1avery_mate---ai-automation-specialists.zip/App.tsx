
import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Bot, 
  Workflow, 
  TrendingUp, 
  Mail, 
  Github, 
  Twitter, 
  Linkedin,
  CheckCircle2,
  ChevronRight,
  Loader2,
  MessageSquare,
  ShieldCheck,
  Rocket,
  Users,
  Target,
  ArrowLeft,
  HelpCircle,
  Send
} from 'lucide-react';
import { analyzeWorkflow } from './services/gemini';
import { AutomationSuggestion } from './types';

type Page = 'home' | 'about';

// --- Shared Components ---

const Navbar = ({ currentPage, setCurrentPage }: { currentPage: Page, setCurrentPage: (p: Page) => void }) => (
  <nav className="fixed top-0 w-full z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <button onClick={() => setCurrentPage('home')} className="flex items-center space-x-2 group">
          <div className="bg-indigo-600 p-1.5 rounded-lg group-hover:rotate-12 transition-transform">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white">Avery_mate</span>
        </button>
        <div className="hidden md:flex items-center space-x-8">
          <button onClick={() => { setCurrentPage('home'); setTimeout(() => document.getElementById('services')?.scrollIntoView({behavior:'smooth'}), 100); }} className="text-slate-300 hover:text-white transition-colors">Services</button>
          <button onClick={() => { setCurrentPage('home'); setTimeout(() => document.getElementById('analyzer')?.scrollIntoView({behavior:'smooth'}), 100); }} className="text-slate-300 hover:text-white transition-colors">AI Demo</button>
          <button onClick={() => setCurrentPage('about')} className={`transition-colors ${currentPage === 'about' ? 'text-indigo-400 font-semibold' : 'text-slate-300 hover:text-white'}`}>About</button>
          <button onClick={() => { setCurrentPage('home'); setTimeout(() => document.getElementById('contact')?.scrollIntoView({behavior:'smooth'}), 100); }} className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-full font-medium transition-all shadow-lg shadow-indigo-500/20">Contact Us</button>
        </div>
      </div>
    </div>
  </nav>
);

const Footer = ({ setCurrentPage }: { setCurrentPage: (p: Page) => void }) => (
  <footer className="bg-slate-950 border-t border-slate-900 pt-16 pb-8">
    <div className="max-w-7xl mx-auto px-4">
      <div className="grid md:grid-cols-4 gap-12 mb-16">
        <div className="col-span-2">
          <div className="flex items-center space-x-2 mb-6">
            <Bot className="w-8 h-8 text-indigo-500" />
            <span className="text-2xl font-bold text-white">Avery_mate</span>
          </div>
          <p className="text-slate-500 max-w-sm mb-6">
            Empowering the next generation of businesses and digital creators with ethical, high-performance AI automation.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors"><Twitter className="w-5 h-5" /></a>
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors"><Linkedin className="w-5 h-5" /></a>
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors"><Github className="w-5 h-5" /></a>
          </div>
        </div>
        <div>
          <h4 className="text-white font-bold mb-6">Explore</h4>
          <ul className="space-y-4 text-slate-500">
            <li><button onClick={() => setCurrentPage('home')} className="hover:text-indigo-400 transition-colors">Home</button></li>
            <li><button onClick={() => setCurrentPage('about')} className="hover:text-indigo-400 transition-colors">Our Story</button></li>
            <li><button onClick={() => { setCurrentPage('home'); setTimeout(() => document.getElementById('analyzer')?.scrollIntoView({behavior:'smooth'}), 100); }} className="hover:text-indigo-400 transition-colors">AI Demo</button></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-bold mb-6">Contact</h4>
          <ul className="space-y-4 text-slate-500">
            <li className="flex items-center"><Mail className="w-4 h-4 mr-2" /> averymate26@gmail.com</li>
            <li><a href="#contact" className="hover:text-indigo-400 transition-colors">Support Inquiry</a></li>
          </ul>
        </div>
      </div>
      <div className="text-center pt-8 border-t border-slate-900 text-slate-600 text-sm">
        <p>© {new Date().getFullYear()} Avery_mate. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

// --- Sections ---

const Hero = ({ onCtaClick }: { onCtaClick: () => void }) => (
  <section className="relative pt-32 pb-20 overflow-hidden">
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none overflow-hidden">
      <div className="absolute top-[-10%] left-[10%] w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[10%] w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-[120px]" />
    </div>
    
    <div className="max-w-7xl mx-auto px-4 text-center">
      <div className="inline-flex items-center space-x-2 bg-indigo-500/10 border border-indigo-500/20 px-4 py-1.5 rounded-full mb-8 animate-bounce-slow">
        <Zap className="w-4 h-4 text-indigo-400" />
        <span className="text-sm font-medium text-indigo-300">Automate your future with Avery_mate</span>
      </div>
      <h1 className="text-5xl md:text-8xl font-black text-white mb-6 leading-[1.1] tracking-tight">
        Work Smarter. <br />
        <span className="gradient-text">Automate Everything.</span>
      </h1>
      <p className="text-xl text-slate-400 max-w-3xl mx-auto mb-10 leading-relaxed">
        We help digital creators, entrepreneurs, and small businesses harness the power of AI to eliminate manual tasks and scale revenue without increasing costs.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
        <button onClick={onCtaClick} className="w-full sm:w-auto px-10 py-5 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center shadow-xl shadow-indigo-500/25">
          Free Workflow Analysis <ChevronRight className="ml-2 w-5 h-5" />
        </button>
        <button onClick={() => { document.getElementById('services')?.scrollIntoView({behavior:'smooth'}) }} className="w-full sm:w-auto px-10 py-5 bg-slate-900 border border-slate-700 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all">
          View Solutions
        </button>
      </div>
    </div>
  </section>
);

const FAQ = () => (
  <section className="py-24 bg-slate-950">
    <div className="max-w-3xl mx-auto px-4">
      <div className="text-center mb-16">
        <HelpCircle className="w-12 h-12 text-indigo-500 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">Frequently Asked Questions</h2>
      </div>
      <div className="space-y-4">
        {[
          { q: "Is AI automation expensive?", a: "Not with us. We specialize in cost-efficient custom agents and internal scripts that pay for themselves in weeks." },
          { q: "Will I lose the human touch?", a: "Our goal is to automate the mundane so you can spend MORE time being human and creative." },
          { q: "How long does setup take?", a: "Most workflows can be analyzed, built, and deployed in under 5 business days." }
        ].map((item, i) => (
          <details key={i} className="group bg-slate-900 rounded-2xl border border-slate-800 p-6 [&_summary::-webkit-details-marker]:hidden">
            <summary className="flex items-center justify-between cursor-pointer list-none">
              <h3 className="text-lg font-bold text-white">{item.q}</h3>
              <span className="text-indigo-500 transition group-open:rotate-180"><ChevronRight /></span>
            </summary>
            <p className="mt-4 text-slate-400 leading-relaxed">{item.a}</p>
          </details>
        ))}
      </div>
    </div>
  </section>
);

// --- Pages ---

const HomePage = ({ onCtaClick }: { onCtaClick: () => void }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<AutomationSuggestion | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async () => {
    if (!input.trim()) return;
    setIsLoading(true);
    setError('');
    try {
      const analysis = await analyzeWorkflow(input);
      setResult(analysis);
    } catch (err) {
      setError('Failed to analyze. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendToTeam = () => {
    if (!result) return;
    const subject = encodeURIComponent(`Avery_mate: New Automation Request - ${result.title}`);
    const body = encodeURIComponent(`
Hi Avery_mate Team,

I've generated an automation plan using your AI tool and I'd like to discuss implementing it.

PROPOSED STRATEGY: ${result.title}
ESTIMATED SAVINGS: ${result.estimatedSavings}

IMPLEMENTATION STEPS:
${result.steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

TECH STACK:
${result.tools.join(', ')}

Please reach out to me to discuss the next steps!
    `);
    window.location.href = `mailto:averymate26@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <>
      <Hero onCtaClick={onCtaClick} />
      
      {/* Services Section */}
      <section id="services" className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Precision Services</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Specialized AI solutions for the modern digital landscape.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all group">
              <Workflow className="w-12 h-12 text-indigo-500 mb-6 group-hover:scale-110 transition-transform" />
              <h3 className="text-xl font-bold text-white mb-3">Workflow Systems</h3>
              <p className="text-slate-400 mb-6">Connect your favorite apps and eliminate data silos automatically.</p>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-indigo-500" /> CRM Integrations</li>
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-indigo-500" /> Auto-Reporting</li>
              </ul>
            </div>
            <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all group">
              <MessageSquare className="w-12 h-12 text-purple-500 mb-6 group-hover:scale-110 transition-transform" />
              <h3 className="text-xl font-bold text-white mb-3">Custom AI Agents</h3>
              <p className="text-slate-400 mb-6">Build bots that understand your business logic and brand voice.</p>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-purple-500" /> 24/7 Support</li>
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-purple-500" /> Lead Qualification</li>
              </ul>
            </div>
            <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all group">
              <TrendingUp className="w-12 h-12 text-emerald-500 mb-6 group-hover:scale-110 transition-transform" />
              <h3 className="text-xl font-bold text-white mb-3">Creator Scaling</h3>
              <p className="text-slate-400 mb-6">Distribute content across 5+ platforms with a single click.</p>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-emerald-500" /> Social Auto-Posting</li>
                <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-emerald-500" /> Engagement Bots</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* AI Analyzer Demo */}
      <section id="analyzer" className="py-24 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-8 md:p-16 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/5 blur-[80px] -z-10" />
            <div className="text-center mb-12">
              <div className="inline-block p-4 bg-indigo-600/10 rounded-2xl mb-6">
                <Bot className="w-10 h-10 text-indigo-500" />
              </div>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Automation Lab</h2>
              <p className="text-slate-400">Describe any repetitive task. Our AI will build an automation plan for you.</p>
            </div>

            <div className="space-y-6">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Example: I need to take customer data from my Shopify orders and create invoices in QuickBooks automatically..."
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-6 text-white placeholder-slate-600 focus:ring-2 focus:ring-indigo-500 outline-none min-h-[160px] text-lg transition-all"
              />
              <button
                onClick={handleAnalyze}
                disabled={isLoading || !input}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-5 rounded-2xl transition-all flex items-center justify-center text-xl shadow-lg shadow-indigo-600/20"
              >
                {isLoading ? (
                  <><Loader2 className="animate-spin mr-3" /> Architecting Solution...</>
                ) : (
                  'Build My Plan'
                )}
              </button>
            </div>

            {error && <p className="mt-4 text-red-400 text-center">{error}</p>}

            {result && (
              <div className="mt-12 p-8 bg-slate-950 rounded-3xl border border-indigo-500/30 animate-in fade-in zoom-in-95 duration-700">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">{result.title}</h3>
                  <div className="px-4 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-xs font-bold uppercase tracking-wider">Plan Ready</div>
                </div>
                <div className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <h4 className="text-indigo-400 font-bold mb-4 flex items-center"><CheckCircle2 className="w-5 h-5 mr-2" /> Action Steps</h4>
                      <ul className="space-y-3">
                        {result.steps.map((step, idx) => (
                          <li key={idx} className="text-slate-300 text-sm flex items-start">
                            <span className="w-5 h-5 flex-shrink-0 bg-slate-800 text-indigo-400 rounded-md flex items-center justify-center text-[10px] font-bold mr-3 mt-0.5">{idx + 1}</span>
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="space-y-6">
                      <div className="p-5 bg-indigo-600/10 rounded-2xl border border-indigo-500/20">
                        <h4 className="text-indigo-400 font-bold mb-2">Cost Impact</h4>
                        <div className="text-3xl font-black text-white">{result.estimatedSavings}</div>
                        <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest">Est. Weekly Recovery</p>
                      </div>
                      <div>
                        <h4 className="text-slate-400 font-bold mb-3 text-sm">Tech Stack</h4>
                        <div className="flex flex-wrap gap-2">
                          {result.tools.map((tool, idx) => (
                            <span key={idx} className="bg-slate-800 text-indigo-300 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-700">
                              {tool}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pt-8 border-t border-slate-800">
                    <button 
                      onClick={handleSendToTeam}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold flex items-center justify-center transition-all shadow-lg shadow-emerald-600/20"
                    >
                      <Send className="w-5 h-5 mr-3" /> Connect with Avery_mate to Implement This
                    </button>
                    <p className="text-center text-slate-500 text-sm mt-4">Send this plan to our team. We'll get back to you with a custom quote.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      <FAQ />

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-[3rem] p-12 md:p-24 text-center text-white shadow-2xl relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-white/10 rounded-full blur-[80px]" />
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-black mb-8">Let's Build the Future Together</h2>
              <p className="text-xl text-indigo-100 mb-12 max-w-2xl mx-auto font-medium">
                Whether you're a digital creator or a small business owner, we have the tools to scale your impact.
              </p>
              
              <div className="flex flex-col items-center space-y-6">
                <a 
                  href="mailto:averymate26@gmail.com" 
                  className="group bg-white text-indigo-600 px-12 py-5 rounded-3xl font-bold text-xl hover:scale-105 transition-all flex items-center shadow-2xl"
                >
                  <Mail className="mr-3 w-7 h-7 group-hover:rotate-12 transition-transform" /> averymate26@gmail.com
                </a>
                <p className="text-indigo-200 font-medium">Available for consulting and long-term automation partnerships.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

const AboutPage = () => (
  <div className="pt-32 pb-24 bg-slate-950 min-h-screen">
    <div className="max-w-7xl mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center gap-16 mb-24">
        <div className="flex-1">
          <div className="inline-block px-4 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-sm font-bold mb-6">Our Mission</div>
          <h1 className="text-5xl md:text-7xl font-black text-white mb-8 leading-tight">The Team Behind <span className="gradient-text">Avery_mate</span></h1>
          <p className="text-xl text-slate-400 leading-relaxed mb-8">
            Founded on the principle that automation should be accessible, not intimidating. We are a boutique AI agency focused exclusively on the needs of entrepreneurs and creative professionals.
          </p>
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="text-3xl font-bold text-white mb-2">50+</h4>
              <p className="text-slate-500">Workflows Automated</p>
            </div>
            <div>
              <h4 className="text-3xl font-bold text-white mb-2">1.2k+</h4>
              <p className="text-slate-500">Hours Saved/Month</p>
            </div>
          </div>
        </div>
        <div className="flex-1 relative">
           <div className="w-full aspect-square bg-slate-900 rounded-full border border-slate-800 flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-indigo-500/10 animate-pulse" />
              <Bot className="w-48 h-48 text-indigo-500 relative z-10" />
           </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-12 mb-24">
        <div className="space-y-4">
          <Target className="w-12 h-12 text-indigo-500" />
          <h3 className="text-2xl font-bold text-white">Efficiency First</h3>
          <p className="text-slate-400 leading-relaxed">We don't build tech for tech's sake. Every automation must result in tangible time or cost savings for our clients.</p>
        </div>
        <div className="space-y-4">
          <Users className="w-12 h-12 text-purple-500" />
          <h3 className="text-2xl font-bold text-white">Human Centric</h3>
          <p className="text-slate-400 leading-relaxed">We believe AI should empower humans, not replace them. Our systems are designed to work alongside you.</p>
        </div>
        <div className="space-y-4">
          <ShieldCheck className="w-12 h-12 text-emerald-500" />
          <h3 className="text-2xl font-bold text-white">Ethical AI</h3>
          <p className="text-slate-400 leading-relaxed">Privacy and data security are at the core of every workflow we build. Your data remains yours.</p>
        </div>
      </div>
    </div>
  </div>
);

// --- Main App Component ---

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  // Handle scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  return (
    <div className="min-h-screen bg-slate-950 font-sans selection:bg-indigo-500 selection:text-white">
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      
      <main>
        {currentPage === 'home' && (
          <HomePage onCtaClick={() => document.getElementById('analyzer')?.scrollIntoView({ behavior: 'smooth' })} />
        )}
        {currentPage === 'about' && (
          <AboutPage />
        )}
      </main>

      <Footer setCurrentPage={setCurrentPage} />
      
      {/* Floating Action Button for Home navigation */}
      {currentPage !== 'home' && (
        <button 
          onClick={() => setCurrentPage('home')} 
          className="fixed bottom-8 left-8 bg-slate-900 border border-slate-800 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-all z-50 flex items-center space-x-2"
        >
          <ArrowLeft className="w-6 h-6" />
          <span className="font-bold pr-2">Back to Home</span>
        </button>
      )}
      <a 
        href="mailto:averymate26@gmail.com" 
        className="fixed bottom-8 right-8 bg-indigo-600 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-all z-50 group"
        title="Quick Mail"
      >
        <Mail className="w-6 h-6 group-hover:rotate-12 transition-transform" />
      </a>
    </div>
  );
}
